function out(elementoId, element, item1, item2) {
        const elemento = document.getElementById(elementoId);
        const elemento_filho = document.getElementById(element);
    
        document.addEventListener('click', function (event) {
            if (!elemento.contains(event.target)) {
                if (elemento_filho.classList.contains(item1)) {
                    elemento_filho.classList.replace(item1, item2);
                }
            }
        });
}

function replace(time, element, item1, item2) {
    time = time * 1000;
    element = document.getElementById(element);
    setTimeout(function() {
        element.classList.replace(item1, item2);
    }, time);
}

function replace2(time, element, item1, item2) {
    time = time * 1000;
    element = document.getElementById(element);
    setTimeout(function() {
      if (element.classList.contains(item1)) {
          element.classList.replace(item1, item2);
      } else {
          element.classList.replace(item2, item1);
      }
    }, time);
}

function replace3(time, element, item1, item2) {
    time = time * 1000;
    let time2 = time
    if (time == 0){
        time2 = 1000
    }

    element = document.getElementById(element);
    setTimeout(function() {
            element.classList.replace(item1, item2);
            setTimeout(function() {
                element.classList.replace(item2, item1);
        }, time2);
    }, time);
}

function replace4(time, time2, element, item1, item2) {
    time = time * 1000;
    time2 = time2 * 1000;
    element = document.getElementById(element);
    setTimeout(function() {
            element.classList.replace(item1, item2);
            setTimeout(function() {
                element.classList.replace(item2, item1);
        }, time2);
    }, time);
}

function add(time, element, item1) {
    time = time * 1000;
    element = document.getElementById(element);
    setTimeout(function() {
            element.classList.add(item1);
    }, time);
}

function add2(time, element, item1) {
    time = time * 1000;
    let time2 = time
    if (time < 1){
        time2 = 1000
    }

    element = document.getElementById(element);
    setTimeout(function() {
            element.classList.add(item1);
            setTimeout(function() {
                element.classList.remove(item1);
        }, time2);
    }, time);
}

function remove(time, element, item2) {
    time = time * 1000;
    element = document.getElementById(element);
    setTimeout(function() {
            element.classList.remove(item2);
    }, time);
}

function remove2(time, element, item1) {
    time = time * 1000;
    let time2 = time
    if (time < 1){
        time2 = 1000
    }

    element = document.getElementById(element);
    setTimeout(function() {
            element.classList.remove(item1);
            setTimeout(function() {
                element.classList.add(item1);
        }, time2);
    }, time);
}
